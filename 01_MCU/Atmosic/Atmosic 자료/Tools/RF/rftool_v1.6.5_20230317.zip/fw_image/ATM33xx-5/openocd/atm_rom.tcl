
proc verify_rom_version {} {
    reset halt
    namespace eval ::CMSDK_WRPR0${::SX}::CHIPREV {
	if {[MAJOR::READ [mrw [REG_ADDR]]] == 1} {
	    return
	}
    }
    if {[mrw 0x10000cbc] == 0x4d4f5200} {
	error "Incompatible with ATM33xx-2 or ATM33xx-3 part!"
    }
    error "Not an ATM33xx-5 part!"
}
