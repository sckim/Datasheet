python rftool.py --gui
pause