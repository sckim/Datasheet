echo off
echo .
echo ............................................................
echo Select [0-2] to program HCI_vendor flash code, or 3 to exit
echo ............................................................
echo .
echo 0 - ATMx2xx-x1x
echo 1 - ATMx2xx-x0x
echo 2 - ATM33xx-5
echo 3 - Exit
echo .

SET /P SEL=Type 0, 1, 2, 3 then press ENTER:
if %SEL%==0 goto ATMX2XX-X1X
if %SEL%==1 goto ATMX2XX-X0X
if %SEL%==2 goto ATM33XX-5
if %SEL%==3 goto END

:ATMX2XX-X0X
SET CHIP_VER=ATMx2xx-x0x
echo .
echo ............................................................
echo Select [0-7] to program HCI_vendor flash code, or 8 to exit
echo ............................................................
echo .
echo 0 - m2201
echo 1 - m2202
echo 2 - m2221
echo 3 - m2251
echo 4 - m3201
echo 5 - m3202
echo 6 - m3221
echo 7 - m3231
echo .

SET /P SEL=Type 0, 1, 2, 3, 4, 5, 6, 7, 8 then press ENTER:
if %SEL%==0 (
        set BOARD=m2201
        goto RUN
)
if %SEL%==1 (
        set BOARD=m2202
        goto RUN
)
if %SEL%==2 (
        set BOARD=m2221
        goto RUN
)
if %SEL%==3 (
        set BOARD=m2251
        goto RUN
)
if %SEL%==4 (
        set BOARD=m3201
        goto RUN
)
if %SEL%==5 (
        set BOARD=m3202
        goto RUN
)
if %SEL%==6 (
        set BOARD=3221
        goto RUN
)
if %SEL%==7 (
        set BOARD=3231
        goto RUN
)
if %SEL%==8 goto END

:ATMX2XX-X1X
SET CHIP_VER=ATMx2xx-x1x
echo .
echo ............................................................
echo Select [0-8] to program HCI_vendor flash code, or 9 to exit
echo ............................................................
echo .
echo 0 - ATMEVK_M2201
echo 1 - ATMEVK_M2202
echo 2 - ATMEVK_M2221
echo 3 - ATMEVK_M2231
echo 4 - ATMEVK_M2251
echo 5 - ATMEVK_M3201
echo 6 - ATMEVK_M3202
echo 7 - ATMEVK_M3221
echo 8 - ATMEVK_M3231
echo .

SET /P SEL=Type 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 then press ENTER:
if %SEL%==0 (
        set BOARD=ATMEVK_M2201
        goto RUN
        )
if %SEL%==1 (
        set BOARD=ATMEVK_M2202
        goto RUN
        )
if %SEL%==2 (
        set BOARD=ATMEVK_M2221
        goto RUN
        )
if %SEL%==3 (
        set BOARD=ATMEVK_M2231
        goto RUN
        )
if %SEL%==4 (
        set BOARD=ATMEVK_M2251
        goto RUN
        )
if %SEL%==5 (
        set BOARD=ATMEVK_M3201
        goto RUN
)
if %SEL%==6 (
        set BOARD=ATMEVK_M3202
        goto RUN
)
if %SEL%==7 (
        set BOARD=ATMEVK_M3221
        goto RUN
)
if %SEL%==8 (
        set BOARD=ATMEVK_M3231
        goto RUN
)
if %SEL%==9 goto END

:ATM33XX-5
SET CHIP_VER=ATM33xx-5
echo .
echo ............................................................
echo Select [0-4] to program HCI_vendor flash code, or 5 to exit
echo ............................................................
echo .
echo 0 - ATMEVK_3325_LQK
echo 1 - ATMEVK_3325_QK
echo 2 - ATMEVK_3325_TAG
echo 3 - ATMEVK_3330_QN
echo 4 - ATMEVK_3330e_QN
echo .

SET /P SEL=Type 0, 1, 2, 3, 4, 5 then press ENTER:
if %SEL%==0 (
        set BOARD=ATMEVK_3325_LQK
        goto RUN
        )
if %SEL%==1 (
        set BOARD=ATMEVK_3325_QK
        goto RUN
        )
if %SEL%==2 (
        set BOARD=ATMEVK_3325_TAG
        goto RUN
        )
if %SEL%==3 (
        set BOARD=ATMEVK_3330_QN
        goto RUN
        )
if %SEL%==4 (
        set BOARD=ATMEVK_3330e_QN
        goto RUN
        )
if %SEL%==5 goto END

:RUN
SET FTDI_BENIGN_BOOT=1
SET FTDI_HARD_RESET=1
SET PATH_OPENOCD_TCL_BASE=.\\fw_image\\openocd-0.10.0\\tcl
SET PATH_OPENOCD_EXE=.\\fw_image\\openocd-0.10.0\\openocd.exe
SET PATH_FW=.\\fw_image\\%CHIP_VER%\\HCI_vendor_%BOARD%.elf
SET PATH_BOOTLOADER=.\\fw_image\\%CHIP_VER%\\bootloader.elf
SET PATH_OPENOCD_TCL=.\\fw_image\\%CHIP_VER%\\openocd

if %SEL% GTR 2 (
SET PATH_OPENOCD_CFG=.\\fw_image\\%CHIP_VER%\\openocd\\atmx3_openocd.cfg
)else (
SET PATH_OPENOCD_CFG=.\\fw_image\\%CHIP_VER%\\openocd\\atm2x_openocd.cfg
)

%PATH_OPENOCD_EXE% -s %PATH_OPENOCD_TCL_BASE% -s %PATH_OPENOCD_TCL% -f %PATH_OPENOCD_CFG% -c "init; exit"
SET FTDI_HARD_RESET=0
%PATH_OPENOCD_EXE% -s %PATH_OPENOCD_TCL_BASE% -s %PATH_OPENOCD_TCL% -f %PATH_OPENOCD_CFG% -c "init; exit"
SET FTDI_BENIGN_BOOT=0
%PATH_OPENOCD_EXE% -s %PATH_OPENOCD_TCL_BASE% -s %PATH_OPENOCD_TCL% -f %PATH_OPENOCD_CFG% -c "init; sleep 200; set_normal_boot; exit"

if %SEL% GTR 2 (
%PATH_OPENOCD_EXE% -s %PATH_OPENOCD_TCL_BASE% -s %PATH_OPENOCD_TCL% -f %PATH_OPENOCD_CFG% -c "init; verify_rom_version; atm_load_rram %PATH_FW%; atm_load_rram %PATH_BOOTLOADER%; set _RESET_HARD_ON_EXIT 1; exit"
)else (
%PATH_OPENOCD_EXE% -s %PATH_OPENOCD_TCL_BASE% -s %PATH_OPENOCD_TCL% -f %PATH_OPENOCD_CFG% -c "init; verify_rom_version; sydney_load_flash %PATH_FW%; set _RESET_HARD_ON_EXIT 1; exit"
)

goto END

:END
echo exit